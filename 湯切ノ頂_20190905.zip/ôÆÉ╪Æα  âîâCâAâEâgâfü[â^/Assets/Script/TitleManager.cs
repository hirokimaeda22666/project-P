﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class TitleManager : MonoBehaviour
{
    public Image back;
    bool Tap = false;
    bool MusicStart = false;
    public AudioSource start;
    public AudioSource Music;
    float timer = 2.0f;
    public Color now;
    Color pnow;

    // Use this for initialization
    void Start()
    {

        now = back.color;
    }

    // Update is called once per frame
    void Update()
    {



        if (!MusicStart)
        {
            MusicStart = true;
            Music.Play();
        }
        //if (Input.GetKeyDown("space")&&!Tap)

        if (Input.GetKey(KeyCode.KeypadEnter))
        {
            Music.Pause();
            start.Play();
            Tap = true;
        }
        if (Tap)
        {
            timer -= Time.deltaTime;
            float a = 1.0f / 2.0f * timer;
            if (a < 0)
            {
                a = 0;
            }
            now.a = a;
            back.color = new Color(now.r, now.g, now.b, a);
        }


    }
}