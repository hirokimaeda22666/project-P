﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class numericKeypadSystem : MonoBehaviour
{

    enum STEP
    {
        Title,
        Game,
        example,
        Score,
        Result,
    }
    STEP step;
    float TitleTimer = 2.0f;
    float ResultTimer = 5.0f;
    bool TitleTap = false;
    // Use this for initialization
    void Start()
    {
        DontDestroyOnLoad(this);
        setScreen(SceneManager.GetActiveScene().name);
    }

    // Update is called once per frame
    void Update()
    {
        setScreen(SceneManager.GetActiveScene().name);
        if (Input.GetKey(KeyCode.KeypadEnter))
        {
            loadScene();
        }

        if (TitleTap)
        {
            TitleTimer -= Time.deltaTime;
        }

        if (TitleTimer <= 0.0f && TitleTap)
        {
            TitleTap = false;
            TitleTimer = 2.0f;
            SceneManager.LoadScene("Game");
        }
        if (SceneManager.GetActiveScene().name=="result2")
        {
            ResultTimer -= Time.deltaTime;
        }


        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Quit();
        }
    }
    public void loadScene()
    {
        setScreen(SceneManager.GetActiveScene().name);
        switch (step)
        {
            case STEP.Title:
                TitleTap = true;
                break;
            case STEP.example:
                SceneManager.LoadScene("Score");
                break;
            case STEP.Result:
                if (ResultTimer <= 0.0f)
                {
                    SceneManager.LoadScene("title");
                }
                break;
        }
    }

    void setScreen(string name)
    {
        if (name == "title") step = STEP.Title;
        else if (name == "Game") step = STEP.Game;
        else if (name == "example") step = STEP.example;
        else if (name == "Score") step = STEP.Score;
        else if (name == "result2") step = STEP.Result;
    }

    public static void Quit()
    {
#if UNITY_STANDALONE
        Application.Quit();
#endif

#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#endif
    }
}
