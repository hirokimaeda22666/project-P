﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ScoreManager : MonoBehaviour {
    public Image MISS;
    public Image TimeImage;
    public Image SkillImage;
    public Image GageImage;
    public Image ResultImage;
    forScoreImageString imageString;
    bool timeCheck = false;
    bool GageCheck = false;
    bool skillCheck = false;
    bool ScoreCheck = false;
    float time=0.0f;
    float SoundTimer = 0.5f;
    int Gage = 0;
    int skill=0;
    int score=0;
    rankingSystem rankingSysytem_;
    float timer = 0.05f;
    public AudioSource pointUP;
    public AudioSource result;
    // Use this for initialization
    void Start () {
        rankingSysytem_ = GameObject.Find("Canvas").GetComponent<rankingSystem>();

        MISS.color = new Color(MISS.color.r, MISS.color.g, MISS.color.b, 0);
        TimeImage.color = new Color(TimeImage.color.r, TimeImage.color.g, TimeImage.color.b, 0);
        SkillImage.color = new Color(SkillImage.color.r, SkillImage.color.g, SkillImage.color.b, 0);
        GageImage.color = new Color(GageImage.color.r, GageImage.color.g, GageImage.color.b, 0);
        ResultImage.color = new Color(ResultImage.color.r, ResultImage.color.g, ResultImage.color.b, 0);
      
        if (rankingSysytem_.GetWaterGage() != 0)
        {
            imageString = GameObject.Find("Canvas").GetComponent<forScoreImageString>();
        }
        else
        {
            MISS.color = new Color(MISS.color.r, MISS.color.g, MISS.color.b, 1);
        }
    }

    // Update is called once per frame
    void Update()
    {
        timer -= Time.deltaTime;
        if (MISS.color.a == 0)
        {
            if (!timeCheck)
            {
                TimeImage.color = new Color(TimeImage.color.r, TimeImage.color.g, TimeImage.color.b, 1);
                if (timer <= 0.0f)
                {
                    timer = 0.001f;
                    time += 0.1f;
                    if (time > rankingSysytem_.GetTime())
                    {
                        pointUP.Play();
                        time = rankingSysytem_.GetTime();
                        timeCheck = true;
                        timer = 0.001f;
                    }
                    if ((int)(time * 100) / 100.0f > 15.0f)
                    {
                        imageString.ImageAttach(15.ToString() + "秒", 1, 3.5f);
                    }
                    else
                    {
                        imageString.ImageAttach(((int)(time * 100) / 100.0f).ToString() + "秒", 1, 3.5f);
                    }
                }
            }
            else
            {
                if ((int)(time * 100) / 100.0f > 15.0f)
                {
                    imageString.ImageAttach(15.ToString() + "秒", 1, 3.5f);
                }
                else
                {
                    imageString.ImageAttach(((int)(time * 100) / 100.0f).ToString() + "秒", 1, 3.5f);
                }
            }
            if (timeCheck && !GageCheck)
            {
                GageImage.color = new Color(GageImage.color.r, GageImage.color.g, GageImage.color.b, 1);
               
                if (timer <= 0.0f)
                {
                    timer = 0.01f;
                    Gage++;
                    if (Gage > rankingSysytem_.GetWaterGage())
                    {
                        pointUP.Play();
                        Gage = rankingSysytem_.GetWaterGage();
                        GageCheck = true;
                        timer = 0.01f;
                    }
                 
                    imageString.ImageAttach(Gage.ToString()+"%", -0.5f, 1.2f);
                }
            }
            if (GageCheck)
            {
                imageString.ImageAttach(Gage.ToString() + "%", -0.5f, 1.2f);
            }
            

            if (GageCheck && !skillCheck)
            {
                SkillImage.color = new Color(SkillImage.color.r, SkillImage.color.g, SkillImage.color.b, 1);
                if (timer <= 0.0f)
                {
                    timer = 0.03f;
                    skill += 11;
                    if (skill >= rankingSysytem_.GetScore())
                    {
                        pointUP.Play();
                        skill = rankingSysytem_.GetScore();
                        skillCheck = true;
                        timer = 0.03f;
                      
                    }
                    imageString.ImageAttach(skill.ToString(), -0.5f, -1.2f);
                }
            }
            if (skillCheck){
                imageString.ImageAttach(skill.ToString(), -0.5f, -1.2f);
            }
            if (skillCheck && !ScoreCheck)
            {
                ResultImage.color = new Color(ResultImage.color.r, ResultImage.color.g, ResultImage.color.b, 1);
                score += 11;
                if (score >= rankingSysytem_.getPlayerScore())
                {
                    result.Play();
                    score = rankingSysytem_.getPlayerScore();
                    ScoreCheck = true;
                }
                imageString.ImageAttach(score.ToString(), 3, -3.5f);
            }
            if (ScoreCheck)
            {
                imageString.ImageAttach(score.ToString(), 3, -3.5f);
            }
            if (Input.GetKey(KeyCode.KeypadEnter)&&ScoreCheck)
            {
                SceneManager.LoadScene("result2");
            }
        }
        else
        {
            if (Input.GetKey(KeyCode.KeypadEnter))
            {
                SceneManager.LoadScene("title");
            }
        }
    }
}
