﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ArrowManager : MonoBehaviour {
    public GameObject gm;//ゲームデータ取得用
    public GameObject arrow;//矢印の位置制御用
    public GameObject Canvas;//ImageString描画用
    public GameObject fanfare;//クリア時音声
    public AudioSource Drum;//ドラムロール音声
    float Persent;//パーセント格納用
    float dPersent = 0;//矢印制御用
    bool effect = false;//fanfareタイミング調整用
    float time = 0.0f;//時間制御
    bool count = true;//ドラムロール調整用
    ImageString imageString;//ImageString利用

	void Start () {
        Persent = (int)(gm.GetComponent<ResultManager>().Persent*100)/100f;//パーセント格納
        imageString = Canvas.GetComponent<ImageString>();//ImageString利用宣言
    }

    void Update()
    {
        time += Time.deltaTime;//経過時間取得
        if (gm.GetComponent<ResultManager>().dnumber>=100)
        {
            imageString.ImageAttach(gm.GetComponent<ResultManager>().dnumber.ToString() + "位", -3, -2);//文字列を画像に変換
        }
        if (gm.GetComponent<ResultManager>().dnumber < 100&& gm.GetComponent<ResultManager>().dnumber >= 10)
        {
            imageString.ImageAttach(" "+gm.GetComponent<ResultManager>().dnumber.ToString() + "位", -3, -2);//文字列を画像に変換
        }
        if ( gm.GetComponent<ResultManager>().dnumber < 10)
        {
            imageString.ImageAttach("  " + gm.GetComponent<ResultManager>().dnumber.ToString() + "位", -3, -2);//文字列を画像に変換
        }
        if (dPersent >= Persent&&!effect)//fanfare起動タイミング
        {
            effect = true;
            Instantiate(fanfare, new Vector3(0, 0, 0), Quaternion.identity);
        }
        if (!effect)//ドラムロール起動タイミング
        {
            dPersent = Persent / 5.0f * time;
            if (count) {
                Drum.Play();
                count = false;
            }
            Vector3 pos = new Vector3(-360+200*dPersent, -290 + 430 * dPersent, 0);//矢印の位置制御
            arrow.transform.localPosition = pos;//矢印の位置制御
        }//-160.140
        else
        {
            /*
            Panel.color = new Color(r, g, b, 0.7f);
            Ptext.color = new Color(255, 255, 255, 1);
            */
           
        }
    }
}
