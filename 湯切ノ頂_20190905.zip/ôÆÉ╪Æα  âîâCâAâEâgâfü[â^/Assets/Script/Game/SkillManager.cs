﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SkillManager : MonoBehaviour {
    public GameObject gameObject;//Image取得
    float timer = 0.8f;//Imageの描画時間
    // Use this for initialization
    void Start() {
    }

    // Update is called once per frame
    void Update() {
        timer -= Time.deltaTime;//経過時間取得
        if (timer < 0.0f)//時間経過後に削除
        {
            Destroy(gameObject);
        }
    }
}
