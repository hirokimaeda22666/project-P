﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Example : MonoBehaviour
{
    CountDown countDown;//CountDown利用
    public bool CLEAR = false;//クリア判定
    SerialHandler SerialHandler_;//ゲームプレイ用
    public float force = 0.0f;//麺にかかった力
    public float water;//水分残量
    float count = 4.0f;//ゲーム開始タイミング

    void Start()
    {
        SerialHandler_ = GameObject.Find("systemManager").GetComponent<SerialHandler>();//ゲームプレイ用
        countDown = GameObject.Find("GameManager").GetComponent<CountDown>();//水分量などのデータ取得用
        water = 100;//初期水分量
    }

    // Update is called once per frame
    void Update()
    {
        if (countDown.countBool)//ゲーム開始タイミング取得
        {
            if (!CLEAR)
            {
                force = SerialHandler_.getForce()*1.5f;//麺にかかる力取得
                if (force >= 30.0f&& !GameObject.Find("Tenku(Clone)") && water > 0)//天空落とし起動時処理
                {
                    water =0.0f;
                }
                if (force != 0 && force >= 5.0f)//湯切り処理
                {
                    water -= force;
                }
                if (water <= 0)//クリア処理
                {
                    water = 0;
                    CLEAR = true;
                }
            }
        }
    }
}
