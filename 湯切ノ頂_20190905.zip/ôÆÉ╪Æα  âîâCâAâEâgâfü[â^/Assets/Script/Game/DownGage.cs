﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class DownGage : MonoBehaviour
{
    public GameObject gameObject;//GameManagerのデータ格納用
    SerialHandler SerialHandler_;//ゲームプレイ用
    public AudioSource fin;//終了SE
    public AudioSource SE;//湯切りSE
    float timer = 0.0f;//終了後遷移待機時間
    public int SkillPoint = 0;//芸術点
    public GameObject Tenku;//天空落としデータ格納用
    public GameObject Canvas;//ImageString描画用
    public Image Finish;//終了時画像格納
    public Image Drop;//こぼした時画像格納
    public Image NotFin;//湯切り失敗画像格納
    public Image Reverce;//戻した時の画像格納
    Animator animator;//cercleのアニメ格納
    Slider _slider;//スライダーデータ格納
    public float hp;//水分残量をスライダーに格納
    float WaterGage;//終了後水分残量格納
    public bool MISS = false;//失敗判定
    public bool REVERCE = false;//麺戻した判定
    public bool CLEAR = false;//クリア判定
    public bool FALL = false;//麺落とした判定

    void Start()
    {
        Finish.color = new Color(Finish.color.r, Finish.color.g, Finish.color.b, 0);//
        Drop.color = new Color(Drop.color.r, Drop.color.g, Drop.color.b, 0);        //ゲーム終了時画像不透明化
        NotFin.color = new Color(NotFin.color.r, NotFin.color.g, NotFin.color.b, 0);//ゲーム終了時画像不透明化
        Reverce.color = new Color(Reverce.color.r, Reverce.color.g, Reverce.color.b, 0);//
        _slider = GameObject.Find("Slider").GetComponent<Slider>();//スライダーのデータ取得
        hp = 1;//スライダー用水分残量初期設定
        SerialHandler_ = GameObject.Find("systemManager").GetComponent<SerialHandler>();//ゲームプレイ用データ取得
        animator = GameObject.Find("cercle").GetComponent<Animator>();//cercleのアニメデータ取得
    }

    void Update()
    {
        if (gameObject.GetComponent<CountDown>().countBool)
        {
            if (!MISS && hp > 0.0f && !CLEAR)
            {
                animator.SetFloat("IsgetForce", GetComponent<Example>().force);//cercleに水分減少量格納（5.0f以上の時にアニメーション起動）
                if (GetComponent<Example>().force >= 5.0f && GetComponent<Example>().force != 0.0f)//水分減少量が5.0f以上の時に起動
                {
                    SE.Play();//湯切りSEを鳴らす
                    if (GetComponent<Example>().force >= 30.0f)
                    {//水分減少量が30.0f以上の時に天空落とし起動
                        TenkuOtoshi(GetComponent<Example>().force);
                    }
                    else
                    {//水分減少量が30.0f以下の時に水分減少
                        hp -= (GetComponent<Example>().force) * 0.01f;
                    }
                }

            }

            if (hp <= 0 && !MISS)//正常にクリア時
            {
                if (!CLEAR)
                {//終了時音声を鳴らす
                    fin.Play();
                }
                CLEAR = true;
                Finish.color = new Color(Finish.color.r, Finish.color.g, Finish.color.b, 1);//終了時画像描画
                timer += Time.deltaTime;
                if (timer > 0.25f)//天空落としの際にcercleのアニメーションがされないことを回避する用
                {
                    animator.SetFloat("IsgetForce", 0);
                }
                if (timer > 3.0f)
                {
                    if (!FALL)
                    {
                        gameObject.GetComponent<GameText_>().SaveData();//データ格納
                        SceneManager.LoadScene("Score");//シーン遷移
                    }
                    else
                    {
                        gameObject.GetComponent<GameText_>().SaveData();//データ格納
                        SceneManager.LoadScene("example");//シーン遷移
                    }
                }
            }
            if (Input.GetKey(KeyCode.KeypadEnter))//麺を落とした時の処理
            {
                MISS = true;
                Drop.color = new Color(Drop.color.r, Drop.color.g, Drop.color.b, 1);//麺を落とした画像を描画
                fin.Play();//終了の音声を鳴らす
            }
            if (Input.GetKey(KeyCode.KeypadPlus))//麺を戻した時の処理
            {
                REVERCE = true;
                MISS = true;
                Reverce.color = new Color(Reverce.color.r, Reverce.color.g, Reverce.color.b, 1);//麺戻した時のフォント

                fin.Play();
            }
            if (Input.GetKey(KeyCode.KeypadMinus))//麺落とした時の処理
            {
                FALL = true;
            }


            if (MISS)//失敗時
            {
                animator.SetFloat("IsgetForce", 0);//cercleのアニメ終了
                timer += Time.deltaTime;
                if (timer > 3.0f)//時間経過後に水分量保存と画面遷移
                {
                    WaterGage = 0;
                    gameObject.GetComponent<rankingSystem>().SetWaterGage(WaterGage);
                    SceneManager.LoadScene("Score");
                }
            }
            if ((int)(gameObject.GetComponent<CountDown>().timer * 100) / 100.0f >= 15.0f)//時間経過時
            {
                if (!MISS)
                {//終了時音声を鳴らす
                    fin.Play();
                }
                animator.SetFloat("IsgetForce", 0);//cercleのアニメ終了
                MISS = true;
                NotFin.color = new Color(NotFin.color.r, NotFin.color.g, NotFin.color.b, 1);//失敗画像を描画
                timer += Time.deltaTime;
                if (timer > 3.0f)//時間経過後に水分量保存と画面遷移
                {
                    WaterGage = (100 - 100 * hp);
                    gameObject.GetComponent<rankingSystem>().SetWaterGage(WaterGage);
                    if (!FALL)
                    {
                        gameObject.GetComponent<GameText_>().SaveData();
                        SceneManager.LoadScene("Score");
                    }
                    else
                    {
                        gameObject.GetComponent<GameText_>().SaveData();
                        SceneManager.LoadScene("example");
                    }
                }
            }
        }
        _slider.value = hp;//ゲージに水分残量を反映
    }
    void TenkuOtoshi(float force)//天空落としの処理
    {
        if (!GameObject.Find("Tenku(Clone)") && hp > 0)
        {
            GameObject prefab = (GameObject)Instantiate(Tenku);
            SkillPoint += (int)(GetComponent<Example>().force) * 10;
            prefab.transform.SetParent(Canvas.transform, false);
            hp = 0.0f;
        }
    }
}