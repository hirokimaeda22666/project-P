﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class DownGage : MonoBehaviour
{
    public GameObject gameObject;
    SerialHandler SerialHandler_;
    public AudioSource fin;
    public AudioSource SE;
    float timer = 0.0f;
    float count;
    public int SkillPoint = 0;
    public GameObject Tenku;
    public GameObject Canvas;
    public Image Finish;
    public Image Drop;
    public Image NotFin;
    Animator animator;
    Slider _slider;
    public float hp;
    float WaterGage;
    public bool MISS = false;
    public bool REVERCE = false;
    public bool CLEAR = false;
    public bool FALL = false;
    void Start()
    {
        Finish.color = new Color(Finish.color.r, Finish.color.g, Finish.color.b, 0);
        Drop.color = new Color(Drop.color.r, Drop.color.g, Drop.color.b, 0);
        NotFin.color = new Color(NotFin.color.r, NotFin.color.g, NotFin.color.b, 0);
        _slider = GameObject.Find("Slider").GetComponent<Slider>();
        hp = 1;
        SerialHandler_ = GameObject.Find("systemManager").GetComponent<SerialHandler>();
        animator = GameObject.Find("cercle").GetComponent<Animator>();
    }
    void Update()
    {
        if (gameObject.GetComponent<CountDown>().countBool)
        {
            if (!MISS && hp > 0.0f && !CLEAR)
            {
                animator.SetFloat("IsgetForce", GetComponent<Example>().force);
                if (GetComponent<Example>().force >= 5.0f && GetComponent<Example>().force != 0.0f)
                {
                    SE.Play();
                    if (GetComponent<Example>().force >= 30.0f)
                    {
                        TenkuOtoshi(GetComponent<Example>().force);
                    }
                    else
                    {
                        hp -= (GetComponent<Example>().force) * 0.01f;
                    }
                }

            }

            if (hp <= 0 && !MISS)//正常にクリア時
            {
                if (!CLEAR)
                {
                    fin.Play();
                }
                CLEAR = true;
                
                Finish.color = new Color(Finish.color.r, Finish.color.g, Finish.color.b, 1);
                timer += Time.deltaTime;
                if (timer > 0.25f)
                {
                    animator.SetFloat("IsgetForce", 0);
                }
                if (timer > 3.0f)
                {
                    if (!FALL)
                    {
                        gameObject.GetComponent<GameText_>().SaveData();
                        SceneManager.LoadScene("Score");
                    }
                    else
                    {
                        gameObject.GetComponent<GameText_>().SaveData();
                        SceneManager.LoadScene("example");
                    }
                }
            }
            if (Input.GetKey(KeyCode.KeypadEnter))
            {
                MISS = true;
                Drop.color = new Color(Drop.color.r, Drop.color.g, Drop.color.b, 1);
                fin.Play();
            }
            if (Input.GetKey(KeyCode.KeypadPlus))
            {
                REVERCE = true;
                MISS = true;
//************************************************************ 麺戻した時のフォント
                fin.Play();
            }
            if (Input.GetKey(KeyCode.KeypadMinus))
            {
                FALL = true;
            }


            if (MISS)//失敗時
            {
                animator.SetFloat("IsgetForce", 0);
                timer += Time.deltaTime;
                if (timer > 3.0f)
                {
                    //  SerialHandler_.Close();
                    WaterGage = 0;
                    gameObject.GetComponent<rankingSystem>().SetWaterGage(WaterGage);
                    SceneManager.LoadScene("Score");
                }
            }
            if ((int)(gameObject.GetComponent<CountDown>().timer * 100) / 100.0f >= 15.0f)
            {//時間経過時
                if (!MISS)
                {
                    fin.Play();
                }
                animator.SetFloat("IsgetForce", 0);
                MISS = true;
                NotFin.color = new Color(NotFin.color.r, NotFin.color.g, NotFin.color.b, 1);
                timer += Time.deltaTime;
                if (timer > 3.0f)
                {
                    // SerialHandler_.Close();
                    WaterGage = (100 - 100 * hp);
                    gameObject.GetComponent<rankingSystem>().SetWaterGage(WaterGage);
                    if (!FALL)
                    {
                        gameObject.GetComponent<GameText_>().SaveData();
                        SceneManager.LoadScene("Score");
                    }
                    else
                    {
                        gameObject.GetComponent<GameText_>().SaveData();
                        SceneManager.LoadScene("example");
                    }
                }
            }
        }
        _slider.value = hp;
    }
    void TenkuOtoshi(float force)
    {
        if (!GameObject.Find("Tenku(Clone)") && hp > 0)
        {
            GameObject prefab = (GameObject)Instantiate(Tenku);
            SkillPoint += (int)(GetComponent<Example>().force) * 10;
            prefab.transform.SetParent(Canvas.transform, false);
            hp = 0.0f;
        }
    }
}