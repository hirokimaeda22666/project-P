﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Example : MonoBehaviour
{
    private GameObject line;
    private GameObject line2;
    private GameObject line3;
    CountDown countDown;
    public bool CLEAR = false;
    SerialHandler SerialHandler_;
    public float force = 0.0f;
    public float water;
    float count = 4.0f;

    void Start()
    {
        SerialHandler_ = GameObject.Find("systemManager").GetComponent<SerialHandler>();
        countDown = GameObject.Find("GameManager").GetComponent<CountDown>();
        water = 100;
    }

    // Update is called once per frame
    void Update()
    {
       
        if (countDown.countBool)
        {
            if (!CLEAR)
            {
                force = SerialHandler_.getForce()*1.5f;
                if (force >= 30.0f&& !GameObject.Find("Tenku(Clone)") && water > 0)
                {
                    water =0.0f;
                }
                if (force != 0 && force >= 5.0f)
                {
                    water -= force;
                }
                if (water <= 0)
                {
                    water = 0;
                    CLEAR = true;
                }
            }
        }
    }
}
