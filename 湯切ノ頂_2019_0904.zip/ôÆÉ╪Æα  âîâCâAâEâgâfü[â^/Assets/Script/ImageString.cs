﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ImageString : MonoBehaviour {
    public GameObject I0;
    public GameObject I1;
    public GameObject I2;
    public GameObject I3;
    public GameObject I4;
    public GameObject I5;
    public GameObject I6;
    public GameObject I7;
    public GameObject I8;
    public GameObject I9;
    public GameObject dot;
    public GameObject number;
    public string ImageNumber;
    // Use this for initialization
    void Start () {
		
	}

    // Update is called once per frame
    public void ImageAttach(string ImageNumber, float Xpos, float Ypos)
    {

        int StrNumber = ImageNumber.Length;
        char[] Image = new char[StrNumber];
        for (int loop = 0; loop < StrNumber; loop++)
        {
            Image[loop] = ImageNumber[loop];
            switch (Image[loop])
            {
                case '0':
                    Instantiate(I0, new Vector2(loop * 2 + Xpos, Ypos), Quaternion.identity);
                    break;
                case '1':
                    Instantiate(I1, new Vector2(loop * 2 + Xpos, Ypos), Quaternion.identity);
                    break;
                case '2':
                    Instantiate(I2, new Vector2(loop * 2 + Xpos, Ypos), Quaternion.identity);
                    break;
                case '3':
                    Instantiate(I3, new Vector2(loop * 2 + Xpos, Ypos), Quaternion.identity);
                    break;
                case '4':
                    Instantiate(I4, new Vector2(loop * 2 + Xpos, Ypos), Quaternion.identity);
                    break;
                case '5':
                    Instantiate(I5, new Vector2(loop * 2 + Xpos, Ypos), Quaternion.identity);
                    break;
                case '6':
                    Instantiate(I6, new Vector2(loop * 2 + Xpos, Ypos), Quaternion.identity);
                    break;
                case '7':
                    Instantiate(I7, new Vector2(loop * 2 + Xpos, Ypos), Quaternion.identity);
                    break;
                case '8':
                    Instantiate(I8, new Vector2(loop * 2 + Xpos, Ypos), Quaternion.identity);
                    break;
                case '9':
                    Instantiate(I9, new Vector2(loop * 2 + Xpos, Ypos), Quaternion.identity);
                    break;
                case '.':
                    Instantiate(dot, new Vector2(loop * 2 + Xpos, Ypos), Quaternion.identity);
                    break;
                case '位':
                    Instantiate(number, new Vector2(loop * 2 + Xpos, Ypos), Quaternion.identity);
                    break;
                default:
                    Debug.Log("画像該当なし");
                    break;
            }
        }
    }
}
