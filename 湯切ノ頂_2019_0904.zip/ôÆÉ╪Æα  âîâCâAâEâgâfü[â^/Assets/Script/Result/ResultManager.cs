﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class ResultManager : MonoBehaviour
{
    public GameObject gm;
    float timer = 5.0f;
    int number;
    public int dnumber = 0;
    int Score;
    int PlayerNumber;
    public float Persent;
    bool effect = false;
    float time = 0.0f;
    // Use this for initialization
    void Start()
    {
        if (gm.GetComponent<rankingSystem>().GetWaterGage() >= 100.0f)
        {
            number = gm.GetComponent<rankingSystem>().getRankingNumber();
            Score = gm.GetComponent<rankingSystem>().getPlayerScore();
            PlayerNumber = gm.GetComponent<rankingSystem>().getRankingAllParticipants();
            Persent = 1.0f - ((float)number - 1.0f) / (float)PlayerNumber;
            /*
            switch (number)
            {
                case 1:
                    Gage.text = "挑戦ありがとう！\n\n最高記録更新だ！！！";
                    break;
                default:
                    Gage.text = "挑戦ありがとう！\n君は" + number + "位だ。\nまだまだ上を目指せるぞ！";
                    break;
            }
            if (number != 1 && number <= 10)
            {
                Gage.text = "挑戦ありがとう！\nおめでとう！！\n" + number + "位に入賞したぞ！";
            }
            */
        }
        else
        {
            Score = gm.GetComponent<rankingSystem>().getPlayerScore();
            PlayerNumber = gm.GetComponent<rankingSystem>().getRankingAllParticipants();
            //RankInAllPlayer.text = "上位" + ((float)number / (float)PlayerNumber * 100).ToString() + "%";
            //Gage.text = "残念...。\n" + (100 - gm.GetComponent<rankingSystem>().GetWaterGage()).ToString() + "%水分が残ってしまったな..。\nあきらめずに挑戦だ！！";
            number = gm.GetComponent<rankingSystem>().getRankingNumber();
            Persent = 1.0f - ((float)number - 1.0f) / (float)PlayerNumber;
            if (number == 1)
            {
                number = gm.GetComponent<rankingSystem>().getRankingNumber();
                Persent = 1.0f - (float)PlayerNumber / (float)PlayerNumber;
            }
            else
            {
                number = gm.GetComponent<rankingSystem>().getRankingNumber();
            }
        }
    }

    // Update is called once per frame
    void Update()
    {
        time += Time.deltaTime;
        if (!effect)
        {
            dnumber = PlayerNumber - (int)((float)(PlayerNumber - number) / 5.0f * time);
            if (dnumber <= number)
            {
                dnumber = number;
                effect = true;
            }
        }

        /*
         timer -= Time.deltaTime;

        if (timer < 0.0f)
        {
            SceneManager.LoadScene("title");
        }
        */
    }
}
