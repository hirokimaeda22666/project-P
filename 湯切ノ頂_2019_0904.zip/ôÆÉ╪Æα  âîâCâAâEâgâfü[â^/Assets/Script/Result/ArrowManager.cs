﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ArrowManager : MonoBehaviour {
    public GameObject gm;
    public GameObject arrow;
    public GameObject Canvas;
    public GameObject fanfare;
    public AudioSource Drum;//Taure
    float Persent;
    float dPersent = 0;
    bool Move = false;
    bool effect = false;
    float time = 0.0f;
    float r, g, b;
    bool count = true;
    ImageString imageString;
	// Use this for initialization
	void Start () {
        Persent = (int)(gm.GetComponent<ResultManager>().Persent*100)/100f;
        imageString = Canvas.GetComponent<ImageString>();
    }

    // Update is called once per frame
    void Update()
    {
        time += Time.deltaTime;
        imageString.ImageAttach(gm.GetComponent<ResultManager>().dnumber.ToString() + "位", -3, 0);
        if (dPersent >= Persent&&!effect)
        {
            effect = true;
            Instantiate(fanfare, new Vector3(0, 0, 0), Quaternion.identity);
        }
        if (!effect)
        {
            dPersent = Persent / 5.0f * time;
            if (count) {
                Drum.Play();
                count = false;
            }
            Vector3 pos = new Vector3(-360+180*dPersent, -290 + 480 * dPersent, 0);
            arrow.transform.localPosition = pos;
        }else
        {
            /*
            Panel.color = new Color(r, g, b, 0.7f);
            Ptext.color = new Color(255, 255, 255, 1);
            */
           
        }
    }
}
