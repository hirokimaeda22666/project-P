﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SkillManager : MonoBehaviour {

    public GameObject gameObject;
    float timer = 0.9f;
    // Use this for initialization
    void Start() {
    }

    // Update is called once per frame
    void Update() {
        timer -= Time.deltaTime;
        if (timer < 0.0f)
        {
            Destroy(gameObject);
        }
    }
}
