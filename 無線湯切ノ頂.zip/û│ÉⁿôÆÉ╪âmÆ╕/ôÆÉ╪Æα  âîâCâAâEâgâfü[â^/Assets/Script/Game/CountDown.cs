﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using UnityEngine.UI;

public class CountDown : MonoBehaviour
{
    float imageTimer = 0.0f;
    public Text text;
    public Text time;
    public Image GameStart;
    public Image TimeImage;
    int Count = 4;
    float count = 4.0f;
    float a;
    public float timer = 15.0f;
    public bool countBool = false;
    public GameObject gameObject;
    ImageString imageString;
    float r, g, b;
    // Use this for initialization
    void Start()
    {
        text.text = Count.ToString();
        r = GameStart.color.a;
        g = GameStart.color.g;
        b = GameStart.color.b;
        GameStart.color = new Color(r, g, b, 0);
        imageString = GameObject.Find("GameManager").GetComponent<ImageString>();
    }

    // Update is called once per frame
    void Update()
    {
        if (gameObject.GetComponent<DownGage>().hp > 0 && !gameObject.GetComponent<DownGage>().MISS)
        {
            if (!countBool)
            {
                if (count > 0.0f)
                {
                    imageString.ImageNumber = 15.0f.ToString();
                    imageString.ImageAttach(imageString.ImageNumber, 2, 6);
                    count -= Time.deltaTime;
                    imageString.ImageNumber = ((int)count).ToString();
                    if ((int)count == 0)
                    {
                        a = 1.0f;
                        GameStart.color = new Color(r, g, b, a);
                    }
                    else
                    {
                        imageString.ImageAttach(imageString.ImageNumber, 0, 0);
                    }
                }
                else
                {
                    countBool = true;
                }
            }
            else
            {
                if (!gameObject.GetComponent<DownGage>().MISS)
                {

                    a -= 0.02f;
                    GameStart.color = new Color(r, g, b, a);
                    timer += Time.deltaTime;
                    imageString.ImageNumber = ((int)((15 - timer) * 100) / 100.0f).ToString();
                    imageString.ImageAttach(imageString.ImageNumber, 2, 6);
                    if (timer >= 15.0f)
                    {
                        imageString.ImageNumber = 0.ToString();
                    }
                }
                else
                {
                    a -= 0.02f;
                    GameStart.color = new Color(r, g, b, a);
                }

            }

        }
        else
        {
            time.text = "";
            TimeImage.color = new Color(0, 0, 0, 0);
        }

    }
}