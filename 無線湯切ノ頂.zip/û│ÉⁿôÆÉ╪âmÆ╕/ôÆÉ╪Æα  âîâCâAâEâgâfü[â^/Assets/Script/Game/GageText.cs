﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GageText : MonoBehaviour
{
    public GameObject WaterGage;
    public Text text;
    ImageString imageString;
    void Start()
    {
        imageString = GameObject.Find("GameManager").GetComponent<ImageString>();
        text.text = "";
    }
    void Update()
    {
        if ((int)(WaterGage.GetComponent<Example>().water)>=0) {
            {
                //text.text =((int)(WaterGage.GetComponent<Example>().water)).ToString();
                imageString.ImageNumber = ((int)(WaterGage.GetComponent<Example>().water)).ToString();
                imageString.ImageAttach(imageString.ImageNumber, 4, -3.5f);
            }
        }
        if (WaterGage.GetComponent<Example>().CLEAR)
        {
            text.text = "0";
        }
    }
}