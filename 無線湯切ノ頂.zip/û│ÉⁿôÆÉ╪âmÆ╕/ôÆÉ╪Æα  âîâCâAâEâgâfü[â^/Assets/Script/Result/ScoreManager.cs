﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ScoreManager : MonoBehaviour {
    public Text ScoreTime;
    public Text ScoreSkill;
    public Text ScoreGage;
    public Text Score;
    public Text Miss;
    public Image TimeImage;
    public Image SkillImage;
    public Image GageImage;
    public Image ResultImage;

    bool timeCheck = false;
    bool GageCheck = false;
    bool skillCheck = false;
    bool ScoreCheck = false;
    float time=0.0f;
    float SoundTimer = 0.5f;
    int Gage = 0;
    int skill=0;
    int score=0;
    rankingSystem rankingSysytem_;
    float timer = 0.05f;
    public AudioSource pointUP;
    public AudioSource result;
    // Use this for initialization
    void Start () {
        rankingSysytem_ = GameObject.Find("Canvas").GetComponent<rankingSystem>();

        ScoreSkill.color = new Color(255, 255, 255, 0);
        ScoreGage.color = new Color(255, 255, 255, 0);
        Score.color = new Color(255, 255, 255, 0);
        Miss.color = new Color(255, 255, 255, 0);
        
        TimeImage.color = new Color(TimeImage.color.r, TimeImage.color.g, TimeImage.color.b, 0);
        SkillImage.color = new Color(SkillImage.color.r, SkillImage.color.g, SkillImage.color.b, 0);
        GageImage.color = new Color(GageImage.color.r, GageImage.color.g, GageImage.color.b, 0);
        ResultImage.color = new Color(ResultImage.color.r, ResultImage.color.g, ResultImage.color.b, 0);
        /*
        time = rankingSysytem_.GetTime();
        Gage = rankingSysytem_.GetWaterGage();
        skill = GetScore();
        Score = getPlayerScore;
        */
        if (rankingSysytem_.GetWaterGage() != 0)
        {
            ScoreSkill.text =  rankingSysytem_.GetScore().ToString();
            ScoreGage.text =  rankingSysytem_.GetWaterGage().ToString() + "% 減らしました。";
            Score.text = rankingSysytem_.getPlayerScore().ToString();
        }
        else
        {
            Miss.color=new Color(0, 0, 0, 1);
        }
    }

    // Update is called once per frame
    void Update()
    {
        timer -= Time.deltaTime;
        if (Miss.color.a == 0)
        {
            if (!timeCheck)
            {
                TimeImage.color = new Color(TimeImage.color.r, TimeImage.color.g, TimeImage.color.b, 1);
                if (timer <= 0.0f)
                {
                    timer = 0.001f;
                    time += 0.1f;
                    if (time > rankingSysytem_.GetTime())
                    {
                        pointUP.Play();
                        time = rankingSysytem_.GetTime();
                        timeCheck = true;
                        timer = 0.001f;
                        ScoreGage.color = new Color(255, 255, 255, 1);
                    }
                    ScoreTime.text = (int)(time * 100) / 100.0f + "秒";
                }
            }
            if (timeCheck && !GageCheck)
            {
                GageImage.color = new Color(GageImage.color.r, GageImage.color.g, GageImage.color.b, 1);
               
                if (timer <= 0.0f)
                {
                    timer = 0.01f;
                    Gage++;
                    if (Gage > rankingSysytem_.GetWaterGage())
                    {
                        pointUP.Play();
                        Gage = rankingSysytem_.GetWaterGage();
                        GageCheck = true;
                        timer = 0.01f;
                        ScoreSkill.color = new Color(255, 255, 255, 1);
                    }
                    ScoreGage.text =  Gage + "% 減らしました。";
                }
            }
            if (GageCheck && !skillCheck)
            {
                SkillImage.color = new Color(SkillImage.color.r, SkillImage.color.g, SkillImage.color.b, 1);
                if (timer <= 0.0f)
                {
                    timer = 0.03f;
                    skill += 11;
                    if (skill >= rankingSysytem_.GetScore())
                    {
                        pointUP.Play();
                        skill = rankingSysytem_.GetScore();
                        skillCheck = true;
                        timer = 0.03f;
                        Score.color = new Color(255, 255, 255, 1);
                    }
                    ScoreSkill.text =  skill.ToString();
                }
            }
            if (skillCheck && !ScoreCheck)
            {
                ResultImage.color = new Color(ResultImage.color.r, ResultImage.color.g, ResultImage.color.b, 1);
                score += 11;
                if (score >= rankingSysytem_.getPlayerScore())
                {
                    result.Play();
                    score = rankingSysytem_.getPlayerScore();
                    ScoreCheck = true;
                }
                Score.text =  score.ToString();
            }
            if (Input.GetKey(KeyCode.KeypadEnter)&&ScoreCheck)
            {
                SceneManager.LoadScene("result2");
            }
        }
        else
        {
            ScoreTime.color = new Color(255, 255, 255, 0);
            if (Input.GetKey(KeyCode.KeypadEnter))
            {
                SceneManager.LoadScene("title");
            }
        }
    }
}
